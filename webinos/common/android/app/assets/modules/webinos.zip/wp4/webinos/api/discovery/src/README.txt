For Descriptions on the demo, see link -

http://dev.webinos.org/redmine/projects/t61/wiki/Service_and_Device_Discovery_using_Bluetooth


TODO:
Remote discovery -> NAT traversal needs to be investigated

For more details or any issue, please contact ziran.sun@samsung.com


