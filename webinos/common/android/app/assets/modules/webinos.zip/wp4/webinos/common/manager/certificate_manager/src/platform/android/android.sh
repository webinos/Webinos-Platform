#!/bin/sh
export ANODE_ROOT=~/data/work/dev/android/anode/
export NODE_ROOT=~/data/work/dev/android/nodejs/node/
export OSSL_ANDROID_ROOT=~/data/work/dev/android/external/openssl-android/
/Applications/android-ndk-r7/ndk-build NDK_PROJECT_PATH=. NDK_APPLICATION_MK=Application.mk V=1

