module.exports = require('./lib/hash.js');
