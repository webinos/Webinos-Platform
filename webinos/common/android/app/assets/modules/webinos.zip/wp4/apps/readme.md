Initial commit for apps folder

