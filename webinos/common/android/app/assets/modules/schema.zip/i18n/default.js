module.exports = {
	validation_error: {
	  de: function() {
		return "Diese Instanz ist nicht gültig";
	  },
	  en: function() {
		return "This instance is not valid";
	  }
	},
	validation_error_type: {
	  de: function(v) {
		return "Ungültiger Typ";
	  },
	  en: function(v) {
		return "Invalid type";
	  }
	},
	validation_error_minLength: {
	  de: function(validation) {
		return "Der Text muss mindestens " + validation.schema.minLength + " Zeichen haben.";
	  },
	  en: function(validation) {
		return "Der Text muss mindestens " + validation.schema.minLength + " Zeichen haben.";
	  }
	}
};
