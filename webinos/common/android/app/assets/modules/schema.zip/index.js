module.exports = require('./lib/environment')
